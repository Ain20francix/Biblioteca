package it.uniroma2.dicii.bd.model.dao;

import it.uniroma2.dicii.bd.exception.DAOException;
import it.uniroma2.dicii.bd.model.domain.BookingFlight;
import it.uniroma2.dicii.bd.model.domain.BookingList;
import it.uniroma2.dicii.bd.model.domain.Passenger;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.*;

public class CopieDAO {
}
