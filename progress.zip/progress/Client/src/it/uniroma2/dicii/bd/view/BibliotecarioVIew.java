package it.uniroma2.dicii.bd.view;

import java.io.IOException;
import java.util.Scanner;

public class BibliotecarioVIew {
    public static int showMenu() throws IOException {
        System.out.println("*********************************");
        System.out.println("*    LIBRARY MENU    *");
        System.out.println("*********************************\n");
        System.out.println("*** What should I do for you? ***\n");
        System.out.println("1) Registrazione Utente");
        System.out.println("2) Registrazione Prestito Utente");
        System.out.println("3) Restituzione Copia Prestito Utente");
        System.out.println("4) Report Copie in Prestito");
        System.out.println("5) Inserimento Copia");
        System.out.println("6) Trasferimento Copia");
        System.out.println("7) Restituzione Copia Trasferita");
        System.out.println("8) Quit");

        Scanner input = new Scanner(System.in);
        int choice = 0;
        while (true) {
            System.out.print("Please enter your choice: ");
            choice = input.nextInt();
            if (choice >= 1 && choice <= 8) {
                break;
            }
            System.out.println("Invalid option");
        }

        return choice;
    }
}
