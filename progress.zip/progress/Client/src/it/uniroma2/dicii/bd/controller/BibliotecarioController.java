package it.uniroma2.dicii.bd.controller;

import it.uniroma2.dicii.bd.exception.DAOException;
import it.uniroma2.dicii.bd.model.dao.BookingListProcedureDAO;
import it.uniroma2.dicii.bd.model.dao.ConnectionFactory;
import it.uniroma2.dicii.bd.model.dao.LoginProcedureDAO;
import it.uniroma2.dicii.bd.model.domain.BookingList;
import it.uniroma2.dicii.bd.model.domain.Role;
import it.uniroma2.dicii.bd.view.AgenziaView;
import it.uniroma2.dicii.bd.view.BibliotecarioVIew;

import java.io.IOException;
import java.sql.SQLException;

public class BibliotecarioController  implements Controller{

    @Override
    public void start() {
        try {
            ConnectionFactory.changeRole(Role.BIBLIOTECARIO);
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        while(true) {
            int choice;
            try {
                choice = BibliotecarioVIew.showMenu();
            } catch(IOException e) {
                throw new RuntimeException(e);
            }

            switch(choice) {
                case 1 -> registraUtente();
                case 2 -> registraPrestitoUtente();
                case 3 -> restituzioneCopia();
                case 4 -> reportCopieNonRestituite();
                case 5 -> inserisciCopia();
                case 6 -> trasferimentoCopia();
                case 7 -> restituzioneCopiaTrasferita();
                case 8 -> System.exit(0);
                default -> throw new RuntimeException("Invalid choice");
            }
        }
    }

    public void registraUtente(){
        throw new RuntimeException("Not implemented yet");
    }
    public void registraPrestitoUtente(){
        throw new RuntimeException("Not implemented yet");
    }
    public void restituzioneCopia(){
        throw new RuntimeException("Not implemented yet");
    }
    public void reportCopieNonRestituite(){
        throw new RuntimeException("Not implemented yet");
    }
    public void inserisciCopia(){
        throw new RuntimeException("Not implemented yet");
    }
    public void trasferimentoCopia(){
        throw new RuntimeException("Not implemented yet");
    }
    public void restituzioneCopiaTrasferita(){
        throw new RuntimeException("Not implemented yet");
    }

    /*public void bookFlight() {
        throw new RuntimeException("Not implemented yet");
    }

    public void bookingList() {
        BookingList bookingList;
        try {
            bookingList = new BookingListProcedureDAO().execute();
        } catch(DAOException e) {
            throw new RuntimeException(e);
        }

        System.out.print(bookingList);
    }

    public void listFlights() {
        throw new RuntimeException("Not implemented yet");
    }*/
}
